export class Type{
    "type1": string;
    "type2": string;

    constructor(type1: string, type2: string){
        this.type1=type1;
        this.type2=type2;
    }
    
}