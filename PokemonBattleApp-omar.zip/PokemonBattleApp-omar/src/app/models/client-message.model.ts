export class ClientMessage {
    message: string;
    
    constructor(message: string){
        this.message = message;
    }
}