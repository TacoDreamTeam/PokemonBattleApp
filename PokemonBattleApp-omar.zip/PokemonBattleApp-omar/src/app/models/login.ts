export class Login {
  trainerUsername: string;
  password: string;

  constructor(trainerUsername:string,password:string){
    this.trainerUsername=trainerUsername;
    this.password=password;
  }
}
